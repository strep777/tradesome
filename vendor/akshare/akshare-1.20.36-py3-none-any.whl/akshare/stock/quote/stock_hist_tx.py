#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""
Date: 2026/11/3 18:00
Desc: 腾讯证券-行情首页-沪深京A股
https://quote.eastmoney.com/
"""

import datetime

import pandas as pd

from akshare.exceptions import InvalidParameterError
from akshare.index.index_stock_zh import (
    _TX_COLUMNS,
    _TX_KLINE_FIELDS,
    _tx_volume_multiplier,
    get_tx_start_year,
)
from akshare.utils import jsonish
from akshare.utils import http
from akshare.utils.tqdm import get_tqdm

_TX_YEARS_PER_REQUEST = 2


def _parse_tx_date(value: str, name: str) -> datetime.date:
    """
    解析 YYYYMMDD 或 YYYY-MM-DD 格式的日期。

    :param value: 日期文本
    :type value: str
    :param name: 参数名，用于报错信息
    :type name: str
    :return: 日期
    :rtype: datetime.date
    """
    text = str(value).strip().replace("-", "")
    if len(text) == 8 and text.isdigit():
        try:
            return datetime.datetime.strptime(text, "%Y%m%d").date()
        except ValueError:
            pass
    raise InvalidParameterError(
        f"{name} 应为 YYYYMMDD 或 YYYY-MM-DD 格式的日期，如 '20240101'，收到 {value!r}"
    )


def _normalize_tx_symbol(symbol: str) -> str:
    """
    标准化腾讯证券股票代码。

    :param symbol: 原始股票代码
    :type symbol: str
    :return: 带市场前缀的股票代码
    :rtype: str
    """
    normalized_symbol = symbol.strip().lower()
    if normalized_symbol.startswith(("sh", "sz", "bj")):
        return normalized_symbol
    if normalized_symbol.startswith(("600", "601", "603", "605", "688", "900")):
        return f"sh{normalized_symbol}"
    if normalized_symbol.startswith(("000", "001", "002", "003", "200", "300", "301")):
        return f"sz{normalized_symbol}"
    if normalized_symbol.startswith(("43", "44", "83", "87", "88", "92")):
        return f"bj{normalized_symbol}"
    return normalized_symbol


def stock_zh_a_hist_tx(
    symbol: str = "sz000001",
    start_date: str = "19000101",
    end_date: str = "20500101",
    adjust: str = "",
) -> pd.DataFrame:
    """
    腾讯证券-日频-股票历史数据
    https://gu.qq.com/sh000919/zs
    :param symbol: 带市场标识的股票或者指数代码
    :type symbol: str
    :param start_date: 开始日期，格式 YYYYMMDD 或 YYYY-MM-DD
    :type start_date: str
    :param end_date: 结束日期，格式 YYYYMMDD 或 YYYY-MM-DD
    :type end_date: str
    :param adjust: choice of {"qfq": "前复权", "hfq": "后复权", "": "不复权"}
    :type adjust: str
    :return: 历史行情数据，其中 volume 统一为股，amount 统一为元
    :rtype: pandas.DataFrame
    """
    symbol = _normalize_tx_symbol(symbol=symbol)
    start = _parse_tx_date(value=start_date, name="start_date")
    end = _parse_tx_date(value=end_date, name="end_date")
    if start > end:
        raise InvalidParameterError(
            f"start_date（{start_date}）不能晚于 end_date（{end_date}）"
        )
    init_start = _parse_tx_date(
        value=get_tx_start_year(symbol=symbol), name="get_tx_start_year"
    )
    start = max(start, init_start)
    url = "https://proxy.finance.qq.com/ifzqgtimg/appstock/app/newfqkline/get"
    # 每次请求覆盖两个自然年（约 490 个交易日，低于单次 640 条的上限），按两年步进
    range_end = min(end.year, datetime.date.today().year) + 1
    big_df = pd.DataFrame()
    tqdm = get_tqdm()
    for year in tqdm(range(start.year, range_end, _TX_YEARS_PER_REQUEST), leave=False):
        params = {
            "_var": f"kline_day{adjust}{year}",
            "param": f"{symbol},day,{year}-01-01,{year + 1}-12-31,640,{adjust}",
            "r": "0.8205512681390605",
        }
        r = http.get(url, params=params)
        data_text = r.text
        data_json = jsonish.loads(data_text[data_text.find("={") + 1 :])["data"][symbol]
        if "day" in data_json.keys():
            temp_df = pd.DataFrame(data_json["day"])
        elif "hfqday" in data_json.keys():
            temp_df = pd.DataFrame(data_json["hfqday"])
        else:
            temp_df = pd.DataFrame(data_json["qfqday"])
        big_df = pd.concat([big_df, temp_df], ignore_index=True)
    if big_df.empty:
        return pd.DataFrame(columns=_TX_COLUMNS)
    big_df = big_df.iloc[:, _TX_KLINE_FIELDS]
    big_df.columns = _TX_COLUMNS
    big_df["date"] = pd.to_datetime(big_df["date"], errors="coerce").dt.date
    big_df["open"] = pd.to_numeric(big_df["open"], errors="coerce")
    big_df["close"] = pd.to_numeric(big_df["close"], errors="coerce")
    big_df["high"] = pd.to_numeric(big_df["high"], errors="coerce")
    big_df["low"] = pd.to_numeric(big_df["low"], errors="coerce")
    big_df["volume"] = pd.to_numeric(big_df["volume"], errors="coerce")
    big_df["turnover"] = pd.to_numeric(big_df["turnover"], errors="coerce")
    big_df["amount"] = pd.to_numeric(big_df["amount"], errors="coerce")
    big_df["volume"] = big_df["volume"] * _tx_volume_multiplier(symbol)
    big_df["turnover"] = big_df["turnover"] / 100
    big_df["amount"] = big_df["amount"] * 10000
    big_df = big_df.drop_duplicates(ignore_index=True)
    big_df.index = pd.to_datetime(big_df["date"], errors="coerce")
    big_df = big_df.sort_index()
    big_df = big_df[pd.Timestamp(start) : pd.Timestamp(end)]
    big_df = big_df.reset_index(drop=True)
    return big_df


if __name__ == "__main__":
    stock_zh_a_hist_tx_df = stock_zh_a_hist_tx(
        symbol="sz000001", start_date="20200101", end_date="20231027", adjust="hfq"
    )
    print(stock_zh_a_hist_tx_df)

    stock_zh_a_hist_tx_df = stock_zh_a_hist_tx(
        symbol="920599", start_date="19000101", end_date="20261102", adjust=""
    )
    print(stock_zh_a_hist_tx_df)
